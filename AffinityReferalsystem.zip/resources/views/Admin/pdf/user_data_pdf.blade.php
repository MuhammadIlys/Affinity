<!-- resources/views/user_data_pdf.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
</head>
<body>
    <h1>User Data for {{ $user->first_name . $user->last_name }}</h1>
    <p>Email: {{ $user->email }}</p>
    <p>phone: {{ $user->phone }}</p>
    <p>Address: {{ $user->address }}</p>
    <p>Amount: {{ $user->total_amount }}</p>
</body>
</html>
