
<?php $__env->startSection('pageName', 'Dashboard | User'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('User.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Referred Users</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body pt-3 table-responsive">
                            <div class="my-3">
                                <span class="card-title">Referred Users</span>
                            </div>
                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">#No</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">First
                                                Name</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Last
                                                Name</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Referred
                                                By</button></th>
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">Email</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Job
                                                Title</button></th>
                                        
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">Phone</button></th>
                                        
                                        
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">Status</button></th>
                                        
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php if($referred_users): ?>
                                        <?php $__currentLoopData = $referred_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referred_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-start">
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($referred_user->first_name); ?></td>
                                                <td><?php echo e($referred_user->last_name); ?></td>
                                                <td><?php echo e(@$referred_user->referrer->first_name . ' ' . @$referred_user->referrer->last_name); ?></td>
                                                <td><?php echo e($referred_user->email); ?></td>
                                                <td><?php echo e($referred_user->job_title); ?></td>
                                                <td><?php echo e($referred_user->phone); ?></td>
                                                
                                                <td><?php echo e($referred_user->status); ?></td>
                                                
                                                
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\User\referred_users\index.blade.php ENDPATH**/ ?>