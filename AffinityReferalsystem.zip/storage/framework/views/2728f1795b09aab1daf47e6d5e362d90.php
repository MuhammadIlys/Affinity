
<?php $__env->startSection('pageName', 'Forgot Password'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4"
        style="background-image: url('<?php echo e(asset('assets/img/login.jpg')); ?>'); background-size:cover; background-position:center">
        <div class="container">

            
            
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">
                    
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="pt-4 pb-2">
                                <h5 class="card-title pb-0 fs-4">Forgot Password?</h5>
                                <p class="small">Please enter your email</p>
                            </div>

                            <form class="row g-3" action="<?php echo e(route('password.email')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <div class="col-12">
                                    <label for="email" class="form-label">Email</label>
                                    <div class="input-group has-validation">
                                        <input type="email" name="email"
                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                            required>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <button class="btn btn-primary w-100" type="submit">Login</button>
                                </div>
                            </form>

                        </div>
                    </div>
                    <?php echo $__env->make('Admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.authLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\Auth\forgot-password.blade.php ENDPATH**/ ?>