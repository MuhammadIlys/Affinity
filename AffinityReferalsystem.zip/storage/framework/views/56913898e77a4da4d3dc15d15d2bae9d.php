
<?php $__env->startSection('pageName', 'Dashboard | Admin'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('User.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Rejected Payouts</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body pt-3 table-responsive">
                            <div class="my-3">
                                <span class="card-title">Rejected Payouts</span>
                            </div>

                        </div>
                        <table class="table table-borderless datatable">
                            <thead>
                                <tr>
                                    <th scope="col" data-sortable="true"><button class="datatable-sorter">#No</button>
                                    </th>
                                    
                                    <th scope="col" data-sortable="true"><button
                                            class="datatable-sorter">Referrer</button></th>
                                    
                                    <th scope="col" data-sortable="true"><button class="datatable-sorter">Amount</button>
                                    </th>
                                    <th scope="col" data-sortable="true"><button class="datatable-sorter">Status</button>
                                    </th>
                                    <th scope="col" data-sortable="true"><button class="datatable-sorter">Created
                                            at</button></th>
                                    <th scope="col" data-sortable="true"><button class="datatable-sorter">Action</button>
                                    </th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php if($payouts): ?>
                                    <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-start">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            
                                            <td><?php echo e($payout->referrer_name ?? 'Nill'); ?></td>
                                            <td><?php echo e($payout->total_amount); ?></td>
                                            <td><?php echo e($payout->status); ?></td>
                                            <td><?php echo e($payout->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('request.approve', encrypt($payout->id))); ?>"
                                                    class="btn btn-sm btn-success mb-1"
                                                    onclick="return confirm('Are you sure you want to Approve this request?')">
                                                    Approve
                                                </a>
                                                <a href="javascript:void(0)" class="btn btn-sm btn-primary mb-1 edit-btn"
                                                    data-id="<?php echo e($payout->id); ?>" data-amount="<?php echo e($payout->total_amount); ?>"
                                                    data-url="<?php echo e(route('request.update', encrypt($payout->id))); ?>">
                                                    Edit
                                                </a> 

                                                <form action="<?php echo e(route('request.delete', encrypt($payout->id))); ?>"
                                                    method="POST" class="d-inline-block">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Are you sure you want to delete this request?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </section>

    </main><!-- End #main -->

    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="editForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Edit Payout</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="totalAmount" class="form-label">Total Amount</label>
                            <input type="number" name="total_amount" id="totalAmount" class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Update</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\Admin\payouts\rejected_payouts.blade.php ENDPATH**/ ?>