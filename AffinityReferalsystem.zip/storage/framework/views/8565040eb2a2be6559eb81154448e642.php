
<?php $__env->startSection('pageName', 'Dashboard | Employees'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('Admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">Home</a></li>
                    <li class="breadcrumb-item active">Employees</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Employees</h5>

                            <!-- Vertical Form -->
                            <form class="row g-3" method="POST"
                                action="<?php echo e(isset($employee) ? route('employees.update', $employee->id) : route('employees.store')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if(isset($employee)): ?>
                                    <?php echo method_field('PUT'); ?>
                                <?php endif; ?>

                                <div class="col-12 col-lg-6">
                                    <label for="first_name" class="form-label">
                                        First Name
                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" class="form-control" id="first_name" name="first_name"
                                        value="<?php echo e(old('first_name', $employee->first_name ?? '')); ?>"
                                        placeholder="eg: John Doe">
                                </div>
                                <div class="col-12 col-lg-6">
                                    <label for="last_name" class="form-label">
                                        Last Name
                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" class="form-control" id="last_name" name="last_name"
                                        value="<?php echo e(old('last_name', $employee->last_name ?? '')); ?>"
                                        placeholder="eg: John Doe">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="email" class="form-label">
                                        Email
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="email" class="form-control" id="email" name="email"
                                        value="<?php echo e(old('email', $employee->email ?? '')); ?>" placeholder="johndoe@gmail.com">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="gender" class="form-label">
                                        Gender
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <select class="form-select" name="gender" aria-label="Gender select">
                                        <option value="" disabled
                                            <?php echo e(old('gender', $employee->gender ?? '') == '' ? 'selected' : ''); ?>>Gender
                                        </option>
                                        <option value="male"
                                            <?php echo e(old('gender', $employee->gender ?? '') == 'male' ? 'selected' : ''); ?>>Male
                                        </option>
                                        <option value="female"
                                            <?php echo e(old('gender', $employee->gender ?? '') == 'female' ? 'selected' : ''); ?>>
                                            Female</option>
                                    </select>

                                </div>
                                <div class="col-12 col-lg-6">
                                    <label for="job_title" class="form-label">
                                        Job Title
                                        <?php $__errorArgs = ['job_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" class="form-control" id="job_title" name="job_title"
                                        value="<?php echo e(old('job_title', $employee->job_title ?? '')); ?>"
                                        placeholder="eg: John Doe">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="phone" class="form-label">
                                        Phone <small class="text-danger">( No spaces or signs allowed )</small>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" class="form-control" id="phone" name="phone"
                                        value="<?php echo e(old('phone', $employee->phone ?? '')); ?>" placeholder="eg: +123345677">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="dob" class="form-label">
                                        DOB
                                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="date" class="form-control" id="dob" name="dob"
                                        value="<?php echo e(old('dob', $employee->dob ?? '')); ?>">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="address" class="form-label">
                                        Address
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="text" class="form-control" id="address" name="address"
                                        value="<?php echo e(old('address', $employee->address ?? '')); ?>" placeholder="1234 Main St">
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="gender" class="form-label">
                                        Referred By
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <select class="form-select" name="referred_by" aria-label="referred_by select">
                                        <?php if($referrers): ?>
                                            <?php $__currentLoopData = $referrers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referrer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($referrer->id); ?>">
                                                    <?php echo e($referrer->first_name . $referrer->last_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="col-12 col-lg-6">
                                    <label for="status" class="form-label">
                                        Status
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger">(<?php echo e($message); ?>)</small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <select class="form-select" name="status" aria-label="Select">
                                        <option value="active"
                                            <?php echo e(old('status', $employee->status ?? '') == 'active' ? 'selected' : ''); ?>>active
                                        </option>
                                        <option value="inactive"
                                            <?php echo e(old('status', $employee->status ?? '') == 'inactive' ? 'selected' : ''); ?>>
                                            Inactive</option>
                                    </select>

                                </div>

                              

                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>


                        </div>
                    </div>
                </div><!-- End Left side columns -->
            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views/Admin/employee/create.blade.php ENDPATH**/ ?>