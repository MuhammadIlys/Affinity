<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('user.index')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('referrer.users')); ?>">
                <i class="bi bi-person"></i>
                <span>Referred Users</span>
            </a>
        </li>

        

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#payouts" data-bs-toggle="collapse" href="#"
                aria-expanded="false">
                <i class="bi bi-gear"></i><span>Payout History</span><i
                    class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="payouts" class="nav-content collapse" data-bs-parent="#sidebar-nav" style="">
                <li>
                    <a href="<?php echo e(route('payout.pending')); ?>">
                        <i class="bi bi-circle"></i><span>Pending Payout</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('payout.completed')); ?>">
                        <i class="bi bi-circle"></i><span>Completed Payout</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('payout.rejected')); ?>">
                        <i class="bi bi-circle"></i><span>Rejected Payout</span>
                    </a>
                </li>
            </ul>
        </li>

        <?php if(Auth::check()): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="<?php echo e(route('logout')); ?>">
                    <i class="bi bi-box-arrow-in-right"></i>
                    <span>Logout</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>

</aside><!-- End Sidebar-->
<?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\User\includes\sidebar.blade.php ENDPATH**/ ?>