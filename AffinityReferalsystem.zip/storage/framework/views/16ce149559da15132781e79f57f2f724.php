
<?php $__env->startSection('pageName', 'Dashboard | Commission Rules'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('Admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">Home</a></li>
                    <li class="breadcrumb-item active">Commission Rules</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

       



    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\Admin\settings\index.blade.php ENDPATH**/ ?>