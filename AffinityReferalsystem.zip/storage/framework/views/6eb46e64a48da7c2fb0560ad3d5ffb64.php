
<?php $__env->startSection('pageName', 'Dashboard | User'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('User.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Pending Payouts</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body pt-3 table-responsive">
                            <div class="my-3">
                                <span class="card-title">Pending Payouts</span>
                            </div>
                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">#No</button></th>
                                        
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Approved By</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Amount</button></th>
                                        <th scope="col" data-sortable="true"><button
                                                class="datatable-sorter">Status</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Created at</button></th>
                                        <th scope="col" data-sortable="true"><button class="datatable-sorter">Action</button></th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php if($payouts): ?>
                                        <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="text-start">
                                                <td><?php echo e($loop->iteration); ?></td>
                                                
                                                <td><?php echo e($payout->approver_name ?? 'Not approved'); ?></td>
                                                <td><?php echo e($payout->total_amount); ?></td>
                                                <td><?php echo e($payout->status); ?></td>
                                                <td><?php echo e($payout->created_at); ?></td>
                                                <td>
                                                    
                                                    <form action="<?php echo e(route('payout.delete',encrypt($payout->id))); ?>" method="POST" class="d-inline-block w-100">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger w-100"
                                                            onclick="return confirm('Are you sure?')">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.userLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\User\payouts\pending_payouts.blade.php ENDPATH**/ ?>