<!-- resources/views/user_data_pdf.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Data</title>
</head>
<body>
    <h1>User Data for <?php echo e($user->first_name . $user->last_name); ?></h1>
    <p>Email: <?php echo e($user->email); ?></p>
    <p>phone: <?php echo e($user->phone); ?></p>
    <p>Address: <?php echo e($user->address); ?></p>
    <p>Amount: <?php echo e($user->total_amount); ?></p>
</body>
</html>
<?php /**PATH D:\Projects\AffinityReferalsystem\resources\views/Admin/pdf/user_data_pdf.blade.php ENDPATH**/ ?>