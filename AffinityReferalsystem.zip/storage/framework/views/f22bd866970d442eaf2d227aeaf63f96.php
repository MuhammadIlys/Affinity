
<?php $__env->startSection('pageName', 'Profile | Admin'); ?>

<?php $__env->startSection('content'); ?>

    <main id="main" class="main">
        <?php echo $__env->make('Admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="pagetitle">
            <h1>Profile</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Profile</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section profile">
            <div class="row">
                <div class="col-12 col-lg-12">
                    <div class="card">

                        <div class="card-body p-5">
                            <div class="d-flex flex-row align-items-center gap-4">
                                <img src="http://127.0.0.1:8000/assets/img/placeholder.jpeg" alt="Profile"
                                    class="rounded-circle border border-2 border-primary" style="width:100px; height:100px">
                                <div>
                                    <h3 class="fw-bolder text-secondary">Emmanuel John</h3>
                                    <h6 class="fw-bold text-secondary">CEO</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body pt-3">
                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered" role="tablist">

                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview"
                                        aria-selected="true" role="tab">Personal Information</button>
                                </li>

                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit"
                                        aria-selected="false" role="tab" tabindex="-1">Edit Profile</button>
                                </li>

                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password"
                                        aria-selected="false" tabindex="-1" role="tab">Change Password</button>
                                </li>

                            </ul>
                            <div class="tab-content pt-2">

                                <div class="tab-pane fade profile-overview active show" id="profile-overview"
                                    role="tabpanel">

                                    <div class=" p-5">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-12 col-lg-4">
                                                    <h5>First Name</h5>
                                                    <h5><?php echo e($user->first_name); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Last Name</h5>
                                                    <h5><?php echo e($user->last_name); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Email</h5>
                                                    <h5><?php echo e($user->email); ?></h5>
                                                </div>

                                            </div>
                                            <div class="row mt-4">
                                                <div class="col-12 col-lg-4">
                                                    <h5>Address</h5>
                                                    <h5><?php echo e($user->address); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Gender</h5>
                                                    <h5><?php echo e($user->gender); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Date of birth</h5>
                                                    <h5><?php echo e($user->dob); ?></h5>
                                                </div>

                                            </div>

                                            <div class="row mt-4">
                                                <div class="col-12 col-lg-4">
                                                    <h5>Job title</h5>
                                                    <h5><?php echo e($user->job_title); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Phone</h5>
                                                    <h5><?php echo e($user->phone); ?></h5>
                                                </div>
                                                <div class="col-12 col-lg-4">
                                                    <h5>Role</h5>
                                                    <h5><?php echo e($user->role); ?></h5>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>

                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit" role="tabpanel">
                                    <div class="p-5">
                                        <div class="card-body">
                                            <form method="POST" action="<?php echo e(route('admin.profile.save')); ?>">
                                                <?php echo csrf_field(); ?>

                                                <div class="row">
                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="first_name" class="form-label">First Name</label>
                                                        <input type="text" class="form-control" id="first_name"
                                                            name="first_name" value="<?php echo e($user->first_name); ?>">
                                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="last_name" class="form-label">Last Name</label>
                                                        <input type="text" class="form-control " id="last_name"
                                                            name="last_name" value="<?php echo e($user->last_name); ?>">
                                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                <div class="row">
                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="email" class="form-label">Email address</label>
                                                        <input type="email" class="form-control " id="email"
                                                            name="email" value="<?php echo e($user->email); ?>"
                                                            aria-describedby="emailHelp">

                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="phone" class="form-label">Phone Number</label>
                                                        <input type="tel" class="form-control" id="phone"
                                                            name="phone" value="<?php echo e($user->phone); ?>">
                                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div> 

                                                
                                                <div class="mb-3">
                                                    <label for="address" class="form-label">Address</label>
                                                    <textarea class="form-control " id="address" name="address" rows="3"><?php echo e($user->address); ?></textarea>
                                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="row">
                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="gender" class="form-label">Gender</label>
                                                        <select class="form-select " id="gender" name="gender">
                                                            <option value="">Select Gender</option>
                                                            <option value="male"
                                                                <?php echo e($user->gender == 'male' ? 'selected' : ''); ?>>Male
                                                            </option>
                                                            <option value="female"
                                                                <?php echo e($user->gender == 'female' ? 'selected' : ''); ?>>Female
                                                            </option>
                                                        </select>
                                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                    
                                                    <div class="col-md-6 mb-3">
                                                        <label for="dob" class="form-label">Date of Birth</label>
                                                        <input type="date" class="form-control" id="dob"
                                                            name="dob" value="<?php echo e($user->dob); ?>">
                                                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="role" class="form-label">Role</label>
                                                    <select class="form-select" id="role" name="role">
                                                        <option value="">Select Role</option>
                                                        <option value="admin"
                                                            <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin
                                                        </option>
                                                        <option value="User"
                                                            <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>User</option>
                                                    </select>
                                                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback">
                                                            <?php echo e($message); ?>

                                                        </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <button type="submit" class="btn btn-primary ms-auto">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade pt-3" id="profile-change-password" role="tabpanel">
                                    <!-- Change Password Form -->

                                    <form action="<?php echo e(route('password.change')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="row mb-3">
                                            <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Current
                                                Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="password" type="password" class="form-control"
                                                    id="currentPassword">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">New
                                                Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="newpassword" type="password" class="form-control"
                                                    id="newPassword">
                                                <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Re-enter
                                                New Password</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="renewpassword" type="password" class="form-control"
                                                    id="renewPassword">
                                                <?php $__errorArgs = ['renewpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <small class="text-danger"><?php echo e($message); ?></small>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">Change Password</button>
                                        </div>
                                    </form>


                                </div>

                            </div><!-- End Bordered Tabs -->

                        </div>
                    </div>
                </div>

                

            </div>
        </section>

    </main><!-- End #main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\AffinityReferalsystem\resources\views\Admin\profile\profile.blade.php ENDPATH**/ ?>